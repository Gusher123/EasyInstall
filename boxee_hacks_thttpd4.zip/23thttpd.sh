#!/bin/sh

mount -o bind /data/hack/www/thttpd.conf /etc/thttpd.conf
killall thttpd