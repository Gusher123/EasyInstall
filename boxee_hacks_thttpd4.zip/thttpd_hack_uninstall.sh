#!/bin/sh

#BASEDIR=`dirname $0`

#touch $BASEDIR/uninstall.log

if [ ! -d /data/hack/www ]
then
   echo thttpd hack not installed
   exit
else
	echo Starting the uninstall of the thttpd hack
	echo Unmounting /etc/thttpd.conf 
	umount /etc/thttpd.conf
	echo Removing the startup script
	rm /data/hack/init.d/23thttpd.sh
	echo Removing all files from /data/hack/www/
	rm /data/hack/www/*
	echo Removing /data/hack/www/
	rmdir /data/hack/www/
	echo Restarting thttpd
	killall thttpd 2>&1
	echo Done!
fi